# AgriOptix — static site

This is a lightweight static website for AgriOptix. It’s ready to deploy on **GitHub Pages** for free.

## Deploy on GitHub Pages

1. Create a GitHub repo named `agrioptix.github.io` (or any repo if you use project pages).
2. Upload all files in this folder to the repo root.
3. In GitHub → Settings → Pages → set Source to `main` branch `/ (root)`.
4. Wait a couple of minutes, your site will be live at `https://<your-username>.github.io/`.

### Use your custom domain (`agri-optix.co.uk`)

- Create a DNS **CNAME** record at your domain host:
  - **Name**: `www`
  - **Value**: `<your-username>.github.io`
- In this project, edit the `CNAME` file to contain your domain (e.g., `www.agri-optix.co.uk`) and commit it.
- Optionally forward the root domain to `www` at your registrar.

## Editing

- Update text in `index.html`
- Colors and layout in `styles.css`
- Logo in `assets/ao_mark.svg`
